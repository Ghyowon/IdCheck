package com.javassem.dao;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository("reviewDAO")
public class ReviewDAOImpl {

	//connection을 sqlSessionTemplate
	@Autowired
		SqlSessionTemplate sqlSession; //root-context.xml에 있음
	
	public String review() {
		return sqlSession.selectOne("review.getDate");
		//sql문에서 하나만 가져오려면 selectOne 여러개는 selectList다.
	}
}
