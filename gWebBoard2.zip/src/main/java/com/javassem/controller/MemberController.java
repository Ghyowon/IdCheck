package com.javassem.controller;

import java.util.Date;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.javassem.domain.MemberVO;
import com.javassem.service.MemberService;

@Controller //controller 어노테이션 선언
@RequestMapping("/user/") // user라는 요청이 들어오면 class가 받을거다
public class MemberController {

	@RequestMapping("{url}.do") //userJoin을 {url}로 변수처리하여 사용할거다
	public String sample(@PathVariable String url) { //url이라는 변수를 가져옴
		return "/user/"+url; //경로를 리턴해줘야함 , user밑에 있다고 해야함
	}

	@Autowired
	MemberService memberService;

	@RequestMapping("userInsert.do")
	public ModelAndView insert(MemberVO memberVO) {
//		System.out.println("userInsert.do 요청확인");
//		System.out.println(memberVO.getUserId());
//		System.out.println(memberVO.getUserName());
		int result = memberService.userInsert(memberVO); //입력하고 result로 결과를 받음 (1로)
		
		String message = "가입되지 않았습니다.";
		if(result > 0) message = memberVO.getUserName() + "님, 가입을 축하합니다.";
		
		ModelAndView mv = new ModelAndView();
		mv.setViewName("user/userJoin_ok");
		mv.addObject("result", result);
		mv.addObject("message", message);
		return mv;
	}
	
	@RequestMapping("login.do")
					// ()에 membervo를 쓰면 알아서 사용자 입력값을 받아온다 , 세션 가져온다
	public String login(MemberVO vo, HttpSession session) {
		/*
		 * 1. 사용자 입력값 가져오기
		 * 2. DB에 해당 정보가 있는지 확인
		 * 3. 해당정보가 있다면 (로그인 성공이라면) / user/Main.jsp 뷰페이지 지정
		 * 4. 그렇지 않다면 (로그인 실패) /user/userLogin.jsp 뷰페이지 지정
		 */
		MemberVO result = memberService.idCheck_Login(vo);
		if(result == null || result.getUserId() == null) {
			//로그인이 실패했으면
			return "/user/userLogin"; //페이지 이동
		}else { //로그인이 성공하면
			session.setAttribute("userName", result.getUserId()); // sessionScope에 userId를 가져와서 저장한다
			session.setAttribute("sessionTime", new Date()); // sessionTime에 자료형 date로 저장을 한다 ->시간을 나타냄
			return "/user/Main"; //성공했으면 페이지 이동
		}
	}
	
	@RequestMapping(value="idCheck.do", produces="application/text;charset=UTF-8")
										//ajax때문에 한글 깨지는거 방지 지정해줘야함
	//****************************************************
	@ResponseBody //응답을 할건데 return 부분이 ajax이기 떄문에 responsebody를 기술해서 페이지 전환을 못하게 한다
				  // String 으로 리턴받는 것은 뷰페이지 지정이다
	public String idCheck(MemberVO vo) {
		MemberVO result = memberService.idCheck_Login(vo);
		String message = "사용가능한 아이디 입니다.";
		if(result != null) message = "이미 사용중인 아이디입니다.";
		return message;
	}
	
}
