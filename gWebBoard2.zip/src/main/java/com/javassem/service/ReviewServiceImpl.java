package com.javassem.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javassem.dao.ReviewDAOImpl;

@Service("reviewService") //이름이 너무 길어서 reviewService로 변수 지정해서 사용
public class ReviewServiceImpl {

	//service에서 reviewDAO의 sqlsession의 review함수를 불러온다
	@Autowired
	ReviewDAOImpl reviewDAO;
	
	//string으로 리턴받아야하기때문에 자료형이 string 이다
	public String review() {
		return reviewDAO.review();
	}
}
