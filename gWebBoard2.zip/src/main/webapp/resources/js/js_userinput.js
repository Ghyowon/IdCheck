$(function(){
	// 사용자의 자료 입력여부를 검사하는 함수
	$('#confirm').click(function(){
    	if( $.trim($("#userId").val()) == '' ){
            alert("아이디를 입력해 주세요.");
            $("#userId").focus();
            return;
        }
    	
    	if($.trim($('#userPass').val())==''){
    		alert("비번입력해주세요.");
    		$('#userPass').focus();
    		return;
    	}
    	
    	if($.trim($('#userPass').val()) != $.trim($('#userPass2').val())){
    		alert("비밀번호가 일치하지 않습니다..");
    		$('#userPass2').focus();
    		return;
    	}
    	
    	
    	if($.trim($('#userName').val())==''){
    		alert("이름입력해주세요.");
    		$('#userName').foucs();
    		return;
    	}
       
        // 자료를 전송합니다.
        document.userinput.submit();
	});
	
	//아이디 중복체크
	$('#userId').keyup(function(){ //keyup이벤트 사용하지 말기
		//alert('a');
        $.ajax({
        	type : 'post',
        	url : 'idCheck.do', //idCheck.do로 이동(요청을 부름)
        	contentType : 'application/x-www-form-urlencoded;charset=UTF-8', //한글 안깨짐
        	data : {userId : $('#userId').val()}, //보내는 데이터 userId라는 이름하에 사용자 입력값을 받아온다
        	success : function(result){ //성공해서 함수연결
        		$('#idCheckResult').text(result) //서버를 주면 결과를 입력
        		//text() -> 글씨만 / html() ->태그까지 넣을 수 있음
        	}
        })
       
	})
})
	
	
	
	
	
	
	
	
	